package com.example.lora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
